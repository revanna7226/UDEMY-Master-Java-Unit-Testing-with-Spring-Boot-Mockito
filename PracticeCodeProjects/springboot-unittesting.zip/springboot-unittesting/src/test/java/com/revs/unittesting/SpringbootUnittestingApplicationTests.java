package com.revs.unittesting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootUnittestingApplicationTests {

	@Test
	void contextLoads() {
	}

}
