package com.revs.unittesting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootUnittestingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootUnittestingApplication.class, args);
	}

}
